import AWS from "aws-sdk";
import csvParser from "csv-parser";


const dynamodb = new AWS.DynamoDB();

export const handler = async (event) => {
    // TODO implement
    const response = {
      statusCode: 200,
      body: JSON.stringify('Hello from Lambda!'),
    };

    const record = event.Records[0];
    const bucketName = record.s3.bucket.name;
    const fileName = record.s3.object.key;
    const dotIndex = fileName.indexOf('.');
    const type = fileName.substring(dotIndex + 1);
    const currentTime = new Date().toLocaleString("en-IN", {timeZone: "Asia/Kolkata"});
    
    if (type === 'csv') {
        const s3Stream = new AWS.S3({
            region: record.awsRegion
        }).getObject({
            Bucket: bucketName,
            Key: fileName
        }).createReadStream();

        const csvParserStream = s3Stream.pipe(csvParser());

        const items = [];
        csvParserStream.on('data', (data) => {
            // Assuming CSV has two columns: key and value
            const item = {
                'fileNames': { S: fileName }, // Partition key
                'key': { S: data.key },  // Sort key
                'value': { S: data.value },
                'Time': { S: currentTime }
            };
            items.push(item);
        });

        csvParserStream.on('end', async () => {
            for (const item of items) {
                const params = {
                    TableName: 'table123',
                    Item: item
                };
                await dynamodb.putItem(params).promise();
            }
            console.log("Items added to DynamoDB successfully.");
        });

        csvParserStream.on('error', (err) => {
            console.error('Error parsing CSV:', err);
        });
    } else {
        const params = {
            TableName: 'table123',
            Item: {
                'fileNames': { S: fileName }, // Partition key
                'contentType': { S: type },  // Sort key
                'Time': { S: currentTime }
            }
        };
        await dynamodb.putItem(params).promise();
        console.log("Item added to DynamoDB successfully.");
    }

    return response;
};
